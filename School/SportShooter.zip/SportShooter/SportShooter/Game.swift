//
//  Game.swift
//  SportSportShooter
//
//  Created by Nate Gygi on 4/28/18.
//  Copyright © 2018 Nate Gygi. All rights reserved.
//

import UIKit

class Game {
    
    var player: Player
    
    init() {
        
    }
    
}
